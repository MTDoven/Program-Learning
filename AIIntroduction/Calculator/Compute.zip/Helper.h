#pragma once
#include "define.h"
#include <random>
#include <chrono>
#include <malloc.h>
#include <iostream>

double random(double mean, double std);
void input(char*& string);
double factorial(double number);